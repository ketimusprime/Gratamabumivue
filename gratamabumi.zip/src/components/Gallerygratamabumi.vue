<template>

    <!-- Instagram Section Begin -->
    <div class="instagram-photo">
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TSP-25.png')">
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">gratama_gallery</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TRISODIUM-PHOSPHATE-TECH-GRADE.png')"> 
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">gratama_gallery</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TRISODIUM-PHOSPATE-ANHYDROUS-FOOD.png">
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">gratama_gallery</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TRIPOTASSIUM-CITRATE-MONOHYDRATE.png">
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">gratama_gallery</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TRIISOPROPANOLLAMINE.png">
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">shayna_gallery</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" style="background-image:url('img/instagram/TITANIUM-DIOXIDE.png">
            <div class="inside-text">
                <i class="ti-instagram"></i>
                <h5><a href="#">shayna_gallery</a></h5>
            </div>
        </div>
    </div>
    <!-- Instagram Section End -->
</template>

<script>

    export default{
    name:'Gallerygratamabumi',
    
    };
</script>