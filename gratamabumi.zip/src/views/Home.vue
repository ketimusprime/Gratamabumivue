<template>
  <div class="home">
    <Headergratamabumi/>
    <Herogratamabumi/>
    <Productgratamabumi/>
    <Gallerygratamabumi/>
    <Footergratamabumi/>  
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
import Headergratamabumi from '@/components/Headergratamabumi.vue';
import Herogratamabumi from '@/components/Herogratamabumi.vue';
import Productgratamabumi from '@/components/Productgratamabumi.vue';
import Gallerygratamabumi from '@/components/Gallerygratamabumi.vue';
import Footergratamabumi from '@/components/Footergratamabumi.vue';

export default {
  name: 'Home',
  components: {
   Headergratamabumi,
   Herogratamabumi,
   Productgratamabumi,
   Gallerygratamabumi,
   Footergratamabumi
   
  }
}
</script>
